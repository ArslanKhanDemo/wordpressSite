<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'B[Zlx,vgW.DH:,zvb:dPVXk0d 1B^iU7TPdnYxil}>:3>_|bo92+h#A>B+Qxw}+w' );
define( 'SECURE_AUTH_KEY',  '_D}Y@H*EP&[~A^F=RH#!9_BfQ&*b:KvTcP_@33<OS=e5+#,CGY!Ga9Tb0OkB!jE3' );
define( 'LOGGED_IN_KEY',    '%dQvhO<jt}yPt2)#D0@yZh GpD 0a5ttlc|wD-.|73e.lU$uD>iZ}I|qXj<6z0Iu' );
define( 'NONCE_KEY',        '>:lt|2lcJis,6>qp/1l{oS~b-l4`H>@6y(!KI?7;Kg Rf#LI|z%tA&u>r-X,]sCX' );
define( 'AUTH_SALT',        'ei=g)NI!PiG%awPa6 >&O <O+*0zV,tiSf5ba1v8F~>VtbH%{1q(cE.ZD@:!l*Ew' );
define( 'SECURE_AUTH_SALT', 'Mi|hKG26t:{6>Sl2%|g }1uNj_qE49rqJid6-nQn=A3&K|T`47]8h_zWLeHtAREs' );
define( 'LOGGED_IN_SALT',   'e/b;Q_k P,yt<6-k2<dGDa?<cP#w$ob|&iMA3GWg.KPZk+%cn(QfMfTdnkivt:a/' );
define( 'NONCE_SALT',       'rO}TiRg#lS-|.juP!TrDb+R_:.!tBFb %!p%nBjd{P#oJkL(0_Oh^@U}$<8xn~,(' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
